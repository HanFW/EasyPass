var exports = module.exports = {}
const config = require('./config.json') // Please edit config.json to include any configurations that you might need

const initConnection = () => {
    const knex = require('knex')({
        client: 'mysql',
        connection: {
            host: config.local_rdb.host,
            user: config.local_rdb.user,
            password: config.local_rdb.password,
            port: config.local_rdb.port,
            database: config.local_rdb.database
        }
    })
    return knex;
}

exports.insertCitizen = (body) => {
    console.log("INSERT CITIZEN");
    const knex = initConnection();

    return knex('CITIZENENTITY')
        .insert(body)
        .then(() => {
            return null;
        })
        .catch((err) => {
            console.log(err)
            console.log("ERROR - INSERT CITIZEN")
            return err;
        })
        .finally(() => {
            knex.destroy();
        })
}

exports.insertEmbassy = (body) => {
    console.log("INSERT EMBASSY");
    const knex = initConnection();

    return knex('EMBASSYENTITY')
        .insert(body)
        .then(() => {
            return null;
        })
        .catch((err) => {
            console.log(err)
            console.log("ERROR - INSERT EMBASSY")
            return err;
        })
        .finally(() => {
            knex.destroy();
        })
}

exports.insertEndorser = (body) => {
    console.log("INSERT ENDORSER");
    const knex = initConnection();

    return knex('ENDORSERENTITY')
        .insert(body)
        .then(() => {
            return null;
        })
        .catch((err) => {
            console.log(err)
            console.log("ERROR - INSERT ENDORSER")
            return err;
        })
        .finally(() => {
            knex.destroy();
        })
}

exports.initConnection = initConnection