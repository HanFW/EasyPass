const request = require('request');
const lib = require('./lib')

var passportData = [
    {
        "$class": "org.acme.easypass.Passport",
        "passportNumber": "citizen001",
        "fullName": "Citizen 001",
        "owner": "resource:org.acme.easypass.Citizen#citizen001"
    },
    {
        "$class": "org.acme.easypass.Passport",
        "passportNumber": "citizen002",
        "fullName": "Citizen 002",
        "owner": "resource:org.acme.easypass.Citizen#citizen002"
    },
    {
        "$class": "org.acme.easypass.Passport",
        "passportNumber": "citizen003",
        "fullName": "Citizen 003",
        "owner": "resource:org.acme.easypass.Citizen#citizen003"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.Passport',
    json: passportData
}, function (error, response, body) {
    console.log(body);
});

var bankData = [
    {
        "$class": "org.acme.easypass.Bank",
        "endorserId": "bank001",
        "organization": "DBS"
    },
    {
        "$class": "org.acme.easypass.Bank",
        "endorserId": "bank002",
        "organization": "OCBC"
    },
    {
        "$class": "org.acme.easypass.Bank",
        "endorserId": "bank003",
        "organization": "HSBC"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.Bank',
    json: bankData
}, function (error, response, body) {
    console.log(body);
});

var transportData = [
    {
        "$class": "org.acme.easypass.TransportationProvider",
        "endorserId": "transport001",
        "organization": "Singapore Airlines"
    },
    {
        "$class": "org.acme.easypass.TransportationProvider",
        "endorserId": "transport002",
        "organization": "China Airlines"
    },
    {
        "$class": "org.acme.easypass.TransportationProvider",
        "endorserId": "transport003",
        "organization": "Air France"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.TransportationProvider',
    json: transportData
}, function (error, response, body) {
    console.log(body);
});

var hotelData = [
    {
        "$class": "org.acme.easypass.Hotel",
        "endorserId": "hotel001",
        "organization": "Le Chardon Mountain Lodges"
    },
    {
        "$class": "org.acme.easypass.Hotel",
        "endorserId": "hotel002",
        "organization": "La Bastide de Gordes"
    },
    {
        "$class": "org.acme.easypass.Hotel",
        "endorserId": "hotel003",
        "organization": "Villa Maïa"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.Hotel',
    json: hotelData
}, function (error, response, body) {
    console.log(body);
});

var hotelData = [
    {
        "$class": "org.acme.easypass.InsuranceCompany",
        "endorserId": "insurance001",
        "organization": "NTUC"
    },
    {
        "$class": "org.acme.easypass.InsuranceCompany",
        "endorserId": "insurance002",
        "organization": "American Express"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.InsuranceCompany',
    json: hotelData
}, function (error, response, body) {
    console.log(body);
});

var spfData = [
    {
        "$class": "org.acme.easypass.SPF",
        "endorserId": "spf001",
        "organization": "Singapore Police Force"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.SPF',
    json: spfData
}, function (error, response, body) {
    console.log(body);
});

var icaData = [
    {
        "$class": "org.acme.easypass.ICA",
        "endorserId": "ica001",
        "organization": "Immigration & Checkpoints Authority of Singapore"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.ICA',
    json: icaData
}, function (error, response, body) {
    console.log(body);
});

var emabssyData = [
    {
        "$class": "org.acme.easypass.Embassy",
        "embassyId": "embassy001",
        "country": "France"
    },
    {
        "$class": "org.acme.easypass.Embassy",
        "embassyId": "embassy002",
        "country": "Italy"
    },
    {
        "$class": "org.acme.easypass.Embassy",
        "embassyId": "embassy003",
        "country": "Germany"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.Embassy',
    json: emabssyData
}, function (error, response, body) {
    console.log(body);
});

var citizenData = [
    {
        "$class": "org.acme.easypass.Citizen",
        "passportNumber": "citizen001",
        "name":"citizen001",
        "passport": "resource:org.acme.easypass.Passport#citizen001"
    },
    {
        "$class": "org.acme.easypass.Citizen",
        "passportNumber": "citizen002",
        "name":"citizen001",
        "passport": "resource:org.acme.easypass.Passport#citizen002"
    },
    {
        "$class": "org.acme.easypass.Citizen",
        "passportNumber": "citizen003",
        "name":"citizen001",
        "passport": "resource:org.acme.easypass.Passport#citizen003"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.Citizen',
    json: citizenData
}, function (error, response, body) {
    console.log(body);
});

var localContactData = [
    {
        "$class": "org.acme.easypass.LocalContactPerson",
        "endorserId": "localcontact001",
        "organization": "Germany"
    },
    {
        "$class": "org.acme.easypass.LocalContactPerson",
        "endorserId": "localcontact002",
        "organization": "France"
    },
    {
        "$class": "org.acme.easypass.LocalContactPerson",
        "endorserId": "localcontact003",
        "organization": "Italy"
    }
];

request.post({
    headers: { 'content-type': 'application/json' },
    url: 'http://localhost:3000/api/org.acme.easypass.LocalContactPerson',
    json: localContactData
}, function (error, response, body) {
    console.log(body);
});

let createCitizen = function () {
    let [citizenList, citizen001, citizen002, citizen003] = [[], {}, {}, {}];
    citizen001.CITIZENID = "citizen001";
    citizen002.CITIZENID = "citizen002";
    citizen003.CITIZENID = "citizen003";
    citizen001.ACCOUNTNUMBER = "citizen001";
    citizen002.ACCOUNTNUMBER = "citizen002";
    citizen003.ACCOUNTNUMBER = "citizen003";
    citizen001.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    citizen002.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    citizen003.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    citizen001.PASSWORDSALT = "12345";
    citizen002.PASSWORDSALT = "12345";
    citizen003.PASSWORDSALT = "12345";
    citizenList.push(citizen001);
    citizenList.push(citizen002);
    citizenList.push(citizen003);
    lib.insertCitizen(citizenList);
}

let createEmbassy = function () {
    let [embassyList, embassy001, embassy002, embassy003] = [[], {}, {}, {}];
    embassy001.EMBASSYID = "embassy001";
    embassy002.EMBASSYID = "embassy002";
    embassy003.EMBASSYID = "embassy003";
    embassy001.ACCOUNTNUMBER = "embassy001";
    embassy002.ACCOUNTNUMBER = "embassy002";
    embassy003.ACCOUNTNUMBER = "embassy003";
    embassy001.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    embassy002.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    embassy003.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    embassy001.PASSWORDSALT = "12345";
    embassy002.PASSWORDSALT = "12345";
    embassy003.PASSWORDSALT = "12345";
    embassy001.COUNTRYNAME = "France";
    embassy002.COUNTRYNAME = "Italy";
    embassy003.COUNTRYNAME = "Germany";
    embassyList.push(embassy001);
    embassyList.push(embassy002);
    embassyList.push(embassy003);
    lib.insertEmbassy(embassyList);
}

let createEndorser = function () {
    let [endorserList, bank001, bank002, bank003, hotel001, hotel002, hotel003, ica001, spf001, insurance001, insurance002, localcontact001, localcontact002, localcontact003, transport001, transport002, transport003] = [[], {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}];
    bank001.ENDORSERID = "bank001";
    bank002.ENDORSERID = "bank002";
    bank003.ENDORSERID = "bank003";
    hotel001.ENDORSERID = "hotel001";
    hotel002.ENDORSERID = "hotel002";
    hotel003.ENDORSERID = "hotel003";
    ica001.ENDORSERID = "ica001";
    spf001.ENDORSERID = "spf001";
    insurance001.ENDORSERID = "insurance001";
    insurance002.ENDORSERID = "insurance002";
    localcontact001.ENDORSERID = "localcontact001";
    localcontact002.ENDORSERID = "localcontact002";
    localcontact003.ENDORSERID = "localcontact003";
    transport001.ENDORSERID = "transport001";
    transport002.ENDORSERID = "transport002";
    transport003.ENDORSERID = "transport003";
    bank001.ACCOUNTNUMBER = "bank001";
    bank002.ACCOUNTNUMBER = "bank002";
    bank003.ACCOUNTNUMBER = "bank003";
    hotel001.ACCOUNTNUMBER = "hotel001";
    hotel002.ACCOUNTNUMBER = "hotel002";
    hotel003.ACCOUNTNUMBER = "hotel003";
    ica001.ACCOUNTNUMBER = "ica001";
    spf001.ACCOUNTNUMBER = "spf001";
    insurance001.ACCOUNTNUMBER = "insurance001";
    insurance002.ACCOUNTNUMBER = "insurance002";
    localcontact001.ACCOUNTNUMBER = "localcontact001";
    localcontact002.ACCOUNTNUMBER = "localcontact002";
    localcontact003.ACCOUNTNUMBER = "localcontact003";
    transport001.ACCOUNTNUMBER = "transport001";
    transport002.ACCOUNTNUMBER = "transport002";
    transport003.ACCOUNTNUMBER = "transport003";
    bank001.ENDORSERNAME = "DBS";
    bank002.ENDORSERNAME = "OCBC";
    bank003.ENDORSERNAME = "HSBC";
    hotel001.ENDORSERNAME = "Le Chardon Mountain Lodges";
    hotel002.ENDORSERNAME = "La Bastide de Gordes";
    hotel003.ENDORSERNAME = "Villa Maïa";
    ica001.ENDORSERNAME = "ICA";
    spf001.ENDORSERNAME = "SPF";
    insurance001.ENDORSERNAME = "NTUC";
    insurance002.ENDORSERNAME = "American Express";
    localcontact001.ENDORSERNAME = "Germany";
    localcontact002.ENDORSERNAME = "France";
    localcontact003.ENDORSERNAME = "Italy";
    transport001.ENDORSERNAME = "Singapore Airlines";
    transport002.ENDORSERNAME = "China Airlines";
    transport003.ENDORSERNAME = "Air France";
    bank001.ENDORSERROLE = "BANK";
    bank002.ENDORSERROLE = "BANK";
    bank003.ENDORSERROLE = "BANK";
    hotel001.ENDORSERROLE = "ACCOMMODATION";
    hotel002.ENDORSERROLE = "ACCOMMODATION";
    hotel003.ENDORSERROLE = "ACCOMMODATION";
    ica001.ENDORSERROLE = "ICA";
    spf001.ENDORSERROLE = "SPF";
    insurance001.ENDORSERROLE = "INSURANCE";
    insurance002.ENDORSERROLE = "INSURANCE";
    localcontact001.ENDORSERROLE = "LOCALCONTACT";
    localcontact002.ENDORSERROLE = "LOCALCONTACT";
    localcontact003.ENDORSERROLE = "LOCALCONTACT";
    transport001.ENDORSERROLE = "TRANSPORTATION";
    transport002.ENDORSERROLE = "TRANSPORTATION";
    transport003.ENDORSERROLE = "TRANSPORTATION";
    bank001.PASSWORDSALT = "12345";
    bank002.PASSWORDSALT = "12345";
    bank003.PASSWORDSALT = "12345";
    hotel001.PASSWORDSALT = "12345";
    hotel002.PASSWORDSALT = "12345";
    hotel003.PASSWORDSALT = "12345";
    ica001.PASSWORDSALT = "12345";
    spf001.PASSWORDSALT = "12345";
    insurance001.PASSWORDSALT = "12345";
    insurance002.PASSWORDSALT = "12345";
    localcontact001.PASSWORDSALT = "12345";
    localcontact002.PASSWORDSALT = "12345";
    localcontact003.PASSWORDSALT = "12345";
    transport001.PASSWORDSALT = "12345";
    transport002.PASSWORDSALT = "12345";
    transport003.PASSWORDSALT = "12345";
    bank001.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    bank002.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    bank003.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    hotel001.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    hotel002.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    hotel003.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    ica001.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    spf001.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    insurance001.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    insurance002.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    localcontact001.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    localcontact002.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    localcontact003.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    transport001.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    transport002.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    transport003.PASSWORD = "390ba5f6b5f18dd4c63d7cda170a0c74";
    endorserList.push(bank001);
    endorserList.push(bank002);
    endorserList.push(bank003);
    endorserList.push(hotel001);
    endorserList.push(hotel002);
    endorserList.push(hotel003);
    endorserList.push(ica001);
    endorserList.push(spf001);
    endorserList.push(insurance001);
    endorserList.push(insurance002);
    endorserList.push(localcontact001);
    endorserList.push(localcontact002);
    endorserList.push(localcontact003);
    endorserList.push(transport001);
    endorserList.push(transport002);
    endorserList.push(transport003);
    lib.insertEndorser(endorserList);
}

createCitizen();
createEmbassy();
createEndorser();