The blockchain data is entrying by using http request and url for the API is: http://localhost:3000/api/
Local database is using MySQL

1. Change MySQL database connection in config.json 
2. npm i
3. npm start